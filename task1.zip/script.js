// Symbolic differentiation function
function computeDerivative() {
    const expression = document.getElementById('expression').value.trim();
    const variable = document.getElementById('variable').value.trim();
    let result;

    // Basic checks
    if (!expression || !variable) {
        result = "Please enter both an expression and a variable.";
    } else {
        try {
            // Perform symbolic differentiation
            result = differentiate(expression, variable);
        } catch (error) {
            result = "Error in processing the expression.";
        }
    }

    // Display result in the result section
    document.getElementById('result').innerText = result;
}

// Function to compute derivative
function differentiate(expression, variable) {
    // Regular expressions to match patterns
    const powerRegex = new RegExp(`(\\d*)\\*?${variable}\\^([0-9]+)`);
    const varTermRegex = new RegExp(`(\\d*)\\*?${variable}`);
    const constantTermRegex = new RegExp(`^\\d+$`);

    // Handle expression with simple cases (powers of x, constants, etc.)
    let derivative = expression.replace(powerRegex, (_, coefficient, power) => {
        // x^n -> n * x^(n-1)
        coefficient = coefficient ? parseInt(coefficient) : 1;
        power = parseInt(power);
        return `${coefficient * power}*${variable}^${power - 1}`;
    });

    // Handle linear terms (coeff * x)
    derivative = derivative.replace(varTermRegex, (_, coefficient) => {
        coefficient = coefficient ? parseInt(coefficient) : 1;
        return `${coefficient}`;
    });

    // Handle constant terms (numbers)
    derivative = derivative.replace(constantTermRegex, () => {
        return '0';
    });

    // Replace multiple operators with proper formatting
    derivative = derivative.replace(/\+/g, ' + ').replace(/-/g, ' - ').replace(/\*/g, ' * ');

    // If the result is empty, return 0 (no derivative)
    return derivative || '0';
}
